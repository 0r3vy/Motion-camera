package dev.motioncamera;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** config/motioncamera.json */
public final class MotionCameraConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("motioncamera.json");

	/** Master switch, toggled with /motioncamera on|off. */
	public boolean enabled = true;
	/** Third-person smoothing: 0.02 (very laggy) .. 1.0 (no smoothing). */
	public double speed = 0.25;
	/** First-person smoothing. */
	public double firstPersonSpeed = 0.3;
	/** Smoothing window (ms) counted from the moment your pearl stops flying (lets the camera glide to the teleport spot). */
	public int exceptionDuration = 1500;

	private static MotionCameraConfig instance = new MotionCameraConfig();

	public static MotionCameraConfig get() {
		return instance;
	}

	public static void load() {
		try {
			if (Files.exists(FILE)) {
				MotionCameraConfig c = GSON.fromJson(Files.readString(FILE), MotionCameraConfig.class);
				if (c != null) instance = c;
			}
			instance.speed = Math.clamp(instance.speed, 0.02, 1.0);
			instance.firstPersonSpeed = Math.clamp(instance.firstPersonSpeed, 0.02, 1.0);
			instance.exceptionDuration = Math.clamp(instance.exceptionDuration, 100, 10000);
			save();
		} catch (Exception e) {
			MotionCameraMod.LOGGER.warn("Motion Camera config error, using defaults", e);
		}
	}

	public static void save() {
		try {
			Files.writeString(FILE, GSON.toJson(instance));
		} catch (Exception e) {
			MotionCameraMod.LOGGER.warn("Motion Camera could not save config", e);
		}
	}
}
