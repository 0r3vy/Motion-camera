package dev.motioncamera;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.network.chat.Component;

/**
 * Client-side command:
 *   /motioncamera on | off | status
 *   /motioncamera <value>                (0.02 - 1.0, sets both third- and first-person smoothing)
 *   /motioncamera thirdperson <value>    (third person)
 *   /motioncamera firstperson <value>    (first person)
 *   /motioncamera duration <ms>          (100 - 10000)
 */
public final class MotionCameraCommand {
	private MotionCameraCommand() {}

	public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher) {
		dispatcher.register(ClientCommandManager.literal("motioncamera")
				.executes(ctx -> status(ctx))
				.then(ClientCommandManager.literal("on").executes(ctx -> setEnabled(ctx, true)))
				.then(ClientCommandManager.literal("off").executes(ctx -> setEnabled(ctx, false)))
				.then(ClientCommandManager.literal("status").executes(ctx -> status(ctx)))
				.then(ClientCommandManager.literal("thirdperson")
						.then(ClientCommandManager.argument("value", DoubleArgumentType.doubleArg(0.02, 1.0))
								.executes(ctx -> {
									MotionCameraConfig.get().speed = DoubleArgumentType.getDouble(ctx, "value");
									MotionCameraConfig.save();
									return status(ctx);
								})))
				.then(ClientCommandManager.literal("firstperson")
						.then(ClientCommandManager.argument("value", DoubleArgumentType.doubleArg(0.02, 1.0))
								.executes(ctx -> {
									MotionCameraConfig.get().firstPersonSpeed = DoubleArgumentType.getDouble(ctx, "value");
									MotionCameraConfig.save();
									return status(ctx);
								})))
				.then(ClientCommandManager.literal("duration")
						.then(ClientCommandManager.argument("ms", IntegerArgumentType.integer(100, 10000))
								.executes(ctx -> {
									MotionCameraConfig.get().exceptionDuration = IntegerArgumentType.getInteger(ctx, "ms");
									MotionCameraConfig.save();
									return status(ctx);
								})))
				.then(ClientCommandManager.argument("value", DoubleArgumentType.doubleArg(0.02, 1.0))
						.executes(ctx -> {
							double v = DoubleArgumentType.getDouble(ctx, "value");
							MotionCameraConfig.get().speed = v;
							MotionCameraConfig.get().firstPersonSpeed = v;
							MotionCameraConfig.save();
							return status(ctx);
						})));
	}

	private static int setEnabled(CommandContext<FabricClientCommandSource> ctx, boolean on) {
		MotionCameraConfig.get().enabled = on;
		MotionCameraConfig.save();
		ctx.getSource().sendFeedback(Component.literal("Motion Camera: " + (on ? "ON" : "OFF")));
		return 1;
	}

	private static int status(CommandContext<FabricClientCommandSource> ctx) {
		MotionCameraConfig c = MotionCameraConfig.get();
		ctx.getSource().sendFeedback(Component.literal(String.format(
				"Motion Camera: %s | speed=%.2f | firstperson=%.2f | duration=%dms",
				c.enabled ? "ON" : "OFF", c.speed, c.firstPersonSpeed, c.exceptionDuration)));
		return 1;
	}
}
