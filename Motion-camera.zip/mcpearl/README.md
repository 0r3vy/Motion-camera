# Motion Camera – Pearl Only (Fabric 1.21.11)

**Motion Camera** is a lightweight, client-side Fabric mod that smooths your camera only when it matters: right after you throw an ender pearl.

From the moment the pearl leaves your hand, while it is flying, and for a short time after you teleport, the camera glides toward your new position instead of snapping to it. Outside that window the camera is 100% vanilla, so normal gameplay feels exactly the same. The mod is purely visual, needs no server-side install, and cannot affect gameplay.

## Features
- Smooth camera transition for ender pearl throws and teleports
- Separate smoothing strength for first and third person
- Adjustable smoothing window after the pearl lands
- In-game command to toggle or tune the mod without editing files

## Requirements
- Minecraft 1.21.11
- Fabric Loader 0.19.5 or newer
- Fabric API
- Java 21+

## Commands
| Command | Description |
|---|---|
| `/motioncamera on` | Enable the mod |
| `/motioncamera off` | Disable the mod (camera stays fully vanilla) |
| `/motioncamera <value>` | Set smoothing for both views (0.02 – 1.0) |
| `/motioncamera thirdperson <value>` | Third-person smoothing (0.02 – 1.0) |
| `/motioncamera firstperson <value>` | First-person smoothing (0.02 – 1.0) |
| `/motioncamera duration <ms>` | Smoothing window after the pearl lands (100 – 10000) |
| `/motioncamera status` | Show the current settings |

Lower values mean smoother, laggier movement; `1.0` means no smoothing. Changes are saved automatically.

## Config
`.minecraft/config/motioncamera.json` – `enabled`, `speed`, `firstPersonSpeed`, `exceptionDuration`

## Build
```
.\gradlew.bat build
```
Output: `build\libs\motion-camera-pearl-1.1.0.jar`
